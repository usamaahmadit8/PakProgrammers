<?php

namespace App\Http\Controllers;

use App\Models\banner;
use App\Models\course;
use App\Models\CourseHeading;
use App\Models\CourseOutline;
use App\Models\CourseRegister;
use App\Models\laguage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class homeController extends Controller
{
    //
    public function getLanguages(){
        $languages=array();
        $languages=laguage::all();
        return $languages;
    }

    public function getCourses(){
        $courses=array();
        $courses=course::all();
        return $courses;
    }
    public function getBanners(){
        $banners=array();
        $banners=banner::all();
        return $banners;
    }

    public function register_course(Request $request){
        try{
            $validateData=Validator::make($request->all(),[
             "first_name"=>"required|max:20",
             "last_name"=>"required|max:20",
             "email"=>"email|required",
             "phone"=>"required",
             "city"=>"required",
             "qualification"=>"required",
             "course"=>"required",
     
            ]);
            if($validateData->fails()){
             return response()->json([
                 'status' => false,
                 'message' => 'validation error',
                 'errors' => $validateData->errors()
             ], 401);
         }
             $request['password']=md5($request->password);
             $user=CourseRegister::create($request->all());
             return response()->json([
                 'status' => true,
                 'message' => 'Registration Successfull.'
                // 'token' => $user->createToken("API TOKEN")->plainTextToken
             ], 200);
         } catch (\Throwable $th) {
             return response()->json([
                 'status' => false,
                 'message' => $th->getMessage()
             ], 500);
         }

    }

    public function getCourseOutline(Request $request){
        $course_id=$request->course_id;
        $complete_course=array();
        $course_outline=CourseHeading::where("course_id",$course_id)->get();
        for($i=0; $i<count($course_outline);$i++){
            $course=CourseOutline::where("course_id",$course_id)
            ->where("course_title_id",$course_outline[$i]->id)
            ->get();
            if(count($course)>0){
                $course_outline[$i]->outline=$course;
            }else{
                $course=array();
                $course_outline[$i]->outline=$course;
            }
        }

        return $course_outline;
    }
}